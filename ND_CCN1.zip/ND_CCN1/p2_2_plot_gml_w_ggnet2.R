#installation
#install.packages('network', repos='http://cran.r-project.org')
#install.packages('sna', repos='http://cran.r-project.org')
#install.packages('devtools', repos='http://cran.r-project.org')
#install.packages('intergraph', repos='http://cran.r-project.org')

#devtools::install_github("briatte/ggnet")

library(network)
library(sna)
library(ggplot2)
library(ggnet)
library(intergraph)
library(igraph)

#stop()
args=commandArgs(trailingOnly=T)
fnin=args[1]
#fnin='daf2daf16_PRIORITIZED_NETWORK.gml'
fnpdf=paste0(fnin, '.pdf')

g=read.graph(fnin,format='gml')
pr=igraph::get.vertex.attribute(g)$props
shapes=rep('circle', length(pr))
shapes[pr=='SOURCE']='csquare'
shapes[pr=='TARGET']='rectangle'
col=igraph::get.vertex.attribute(g)$colors


net=asNetwork(g)                                                                                                              
shapes_pch=rep(16, length(pr))#16 as filled circle
shapes_pch[pr=='SOURCE']=18
shapes_pch[pr=='TARGET']=15
gn=ggnet2(net, label=T, color=col, shape=shapes_pch, arrow.size=5, arrow.gap=0.025)  
pdf(fnpdf)
print(gn)
dev.off()
