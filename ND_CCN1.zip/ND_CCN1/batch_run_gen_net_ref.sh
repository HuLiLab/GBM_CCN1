#!/bin/bash


export STAGE=gen_net_ref
./run_netdecoder_sg_list1_cen_cyr61pos_vs_control.sh     &
./run_netdecoder_sg_listccn1_cen_cyr61pos_vs_control.sh  &
wait


