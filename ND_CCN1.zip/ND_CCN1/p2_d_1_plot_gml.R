library(igraph)

#args=commandArgs(trailingOnly=T)
#fnin=args[1]
fnin='daf2daf16_PRIORITIZED_NETWORK.gml'
fnpdf=paste0(fnin, '.pdf')

g=read.graph(fnin,format='gml')
pr=get.vertex.attribute(g)$props
shapes=rep('circle', length(pr))
shapes[pr=='SOURCE']='csquare'

shapes[pr=='TARGET']='rectangle'
col=get.vertex.attribute(g)$colors
#stop()
pdf(fnpdf)
plot.igraph(g, vertex.color=get.vertex.attribute(g)$colors, vertex.shape=shapes)

dev.off()
