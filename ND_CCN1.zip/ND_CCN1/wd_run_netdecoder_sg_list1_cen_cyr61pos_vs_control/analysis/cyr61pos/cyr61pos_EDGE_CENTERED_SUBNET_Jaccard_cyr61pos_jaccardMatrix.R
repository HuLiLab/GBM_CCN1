library(gplots);
library(ggplot2);
library(grid); 
library(reshape); 
library(reshape2); 
library(plyr); 
library(RColorBrewer); 
library(igraph); 
library(Vennerable); 
sim <- read.csv('/data2/syspharm/projects/20170331_dileep_netdecoder/glioma/wd_run_netdecoder_sg_list1_cen_cyr61pos_vs_control//analysis/cyr61pos/cyr61pos_EDGE_CENTERED_SUBNET_Jaccard_cyr61pos.txt', sep='	'); 
names <- as.vector(sim$X); 
sim <- sim[,2:dim(sim)[2]]; 
rownames(sim) <- names; 
hmcols<- colorRampPalette(c("black", "yellow")); 
pdf(file='/data2/syspharm/projects/20170331_dileep_netdecoder/glioma/wd_run_netdecoder_sg_list1_cen_cyr61pos_vs_control//analysis/cyr61pos/cyr61pos_EDGE_CENTERED_SUBNET_Jaccard_cyr61pos.pdf', width=5, height=5); 
heatmap.2(as.matrix(t(sim)), col=hmcols,trace="none", density.info="none", scale="none",margin=c(15,15), key=TRUE, Rowv=T, Colv=T,srtCol=60, dendrogram="none", cexCol=0.55, cexRow=0.55, symm=T,  sepcolor='black'); 
dev.off(); 
#--------------------------------------------------------------------------
