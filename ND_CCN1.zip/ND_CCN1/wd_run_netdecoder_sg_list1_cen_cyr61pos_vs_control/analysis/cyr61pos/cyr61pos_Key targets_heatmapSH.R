library(gplots);
library(ggplot2);
library(grid); 
library(reshape); 
library(reshape2); 
library(plyr); 
library(RColorBrewer); 
library(igraph); 
library(Vennerable); 
df <- read.table('/data2/syspharm/projects/20170331_dileep_netdecoder/glioma/wd_run_netdecoder_sg_list1_cen_cyr61pos_vs_control//analysis/cyr61pos/cyr61pos_SINKS.txt', sep='	', header = TRUE); 
matrix.m <- melt(df, id=c('gene')); 
matrix.m$gene <- factor(matrix.m$gene, levels=matrix.m[order(matrix.m$value, decreasing=FALSE), 'gene']); 
range <- range(matrix.m$value); 
pdf(file='/data2/syspharm/projects/20170331_dileep_netdecoder/glioma/wd_run_netdecoder_sg_list1_cen_cyr61pos_vs_control//analysis/cyr61pos/cyr61pos_Key targets.pdf', width=2.3, height=3.5);
figure <- ggplot(matrix.m, aes(variable, gene)) + geom_tile(aes(fill = value), colour = "black") + scale_fill_gradient2("flow
difference", limits=range, low="blue", high="red", guide="colorbar") + theme_bw() + xlab("") + ylab("") + theme(legend.key.size = unit(0.3, "cm"), panel.grid=element_blank(), panel.border=element_blank(),legend.position="right", legend.direction="vertical") + theme(axis.text.x = element_text(size=rel(0.75), angle=45, hjust=1), axis.text.y = element_text(size = rel(0.75), angle = 00)) + ggtitle('Key targets'); 
print(figure); 
dev.off(); 
#--------------------------------------------------------------------------
