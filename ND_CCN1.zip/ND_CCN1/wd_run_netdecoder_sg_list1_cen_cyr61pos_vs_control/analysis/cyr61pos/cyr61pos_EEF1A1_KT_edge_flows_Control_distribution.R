library(gplots);
library(ggplot2);
library(grid); 
library(reshape); 
library(reshape2); 
library(plyr); 
library(RColorBrewer); 
library(igraph); 
library(Vennerable); 
df <- read.table('/data2/syspharm/projects/20170331_dileep_netdecoder/glioma/wd_run_netdecoder_sg_list1_cen_cyr61pos_vs_control//analysis/cyr61pos/cyr61pos_EEF1A1_KT_edge_flows_Control.txt', sep='	', header = TRUE); 
df <- data.frame(condition=df$flows); 
pdf(file='/data2/syspharm/projects/20170331_dileep_netdecoder/glioma/wd_run_netdecoder_sg_list1_cen_cyr61pos_vs_control//analysis/cyr61pos/cyr61pos_EEF1A1_KT_edge_flows_Control.pdf', width=2, height=2); 
figure <- ggplot(df, aes(x=condition)) + xlim(0, 1) + geom_histogram(binwidth=0.1, alpha=0.7, colour="white", fill="black") +  xlab("Edge flow") + ylab("Number of edges") + theme_bw() + theme(panel.grid = element_blank(), panel.border=element_blank(), axis.line = element_line(colour = "black"), axis.title=element_text(size=10)) + theme(axis.text.x = element_text(size=8, angle=0, hjust=1), axis.text.y = element_text(size=8, hjust=1)) + ggtitle('Control'); 
plot(figure); 
dev.off(); 
#--------------------------------------------------------------------------
