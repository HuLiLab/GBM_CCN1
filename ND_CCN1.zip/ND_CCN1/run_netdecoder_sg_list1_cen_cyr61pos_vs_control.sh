#!/bin/bash
#
set -x

#cen: co-expression network
#sg: signature genes
 
fullname=`readlink -f $0`
mypath=`dirname $fullname`
mybasename=`basename $0 .sh`
wd_basename=wd_$mybasename

#python script 1
S1_EXTRACT_GENES=$mypath/p1_collect_genes_for_netdecoder_output.py
S2_PLOT_GRAPH=$mypath/p2_2_plot_gml_w_ggnet2.R
BASE_DIR=$mypath/$wd_basename/

S3_COLLAGE=$mypath/p2_3_collage_pdfs.py
JAVA=/usr/local/biotools/java/jdk1.8.0_91/bin/java

INPUT_DIR=/data2/syspharm/projects/20170331_dileep_netdecoder/glioma
LIB_DIR=/data2/syspharm/projects/m143944/NetDecoder_20160911_cheng/lib
FILES_DIR=$LIB_DIR
LIB=$LIB_DIR/NetDecoder.jar:$LIB_DIR/commons-cli-1.2.jar

#wormbase, for c elegans
SYMBOL=$FILES_DIR/gene_associationgoa_ref_HUMAN_25Jun2014.txt

GO=$FILES_DIR/gene_ontology_ext_FULL.obo

#########################
curdir=`pwd`




#input arguments
geneList=$INPUT_DIR/gene_list.txt
state_trt=cyr61pos
state_ref=control
PPI_trt=$INPUT_DIR/co_expression_network_glioma_Cyr61positive.txt
PPI_ref=$INPUT_DIR/co_expression_network_glioma_control.txt

mkdir -p $BASE_DIR
cd $BASE_DIR
#stage
#"all"
#"gen_net_trt"
#"gen_net_ref"
#"analysis"
#"collect"

OUTPUT_PATH_networks=$BASE_DIR/networks/
OUTPUT_PATH_analysis=$BASE_DIR/analysis/
OUTPUT_PATH_collect=$BASE_DIR/collect/



network_trt=$OUTPUT_PATH_networks/Network_${state_trt}_paths.ser
network_ref=$OUTPUT_PATH_networks/Network_${state_ref}_paths.ser

echo $STAGE

if [[ $STAGE == "" ]]
then
  exit
fi
if [[ $STAGE == "gen_net_trt" ]] || [[ $STAGE == "all" ]] || [[ $STAGE == "gen" ]] 
then

  OUT_DIR=$OUTPUT_PATH_networks
  #OUT_DIR is a prefix, so add slash at the end
  mkdir -p $OUT_DIR
  
  ###################################################
  PPI=$PPI_trt
  state=$state_trt
  fCompositeNetwork=Network_$state_trt
  #output filename for context scores
  
  echo "1) Computing subnetworks for $state state"
  $JAVA -cp $LIB "netdecoder.NetDecoder" -PPI $PPI -SYMBOL $SYMBOL -GO $GO -g $geneList -out $OUT_DIR -gen -d $state -f $fCompositeNetwork 


fi


#############################################
if [[ $STAGE == "gen_net_ref" ]] || [[ $STAGE == "all" ]] || [[ $STAGE == "gen" ]] 
then

  OUT_DIR=$OUTPUT_PATH_networks
  #OUT_DIR is a prefix, so add slash at the end
  mkdir -p $OUT_DIR
  
  PPI=$PPI_ref
  state=$state_ref
  fCompositeNetwork=Network_$state_ref
  #output filename for context scores
  echo "2) Computing subnetworks for $state state"
  $JAVA -cp $LIB "netdecoder.NetDecoder" -PPI $PPI -SYMBOL $SYMBOL -GO $GO -g $geneList -out $OUT_DIR -gen -d $state -f $fCompositeNetwork 
fi

if [[ $STAGE == "analysis" ]] || [[ $STAGE == "all" ]] 
then

  OUT_DIR=$OUTPUT_PATH_analysis
  mkdir -p $OUT_DIR
  cd $OUT_DIR
  #OUT_DIR is a prefix, so add slash at the end
  network_trt=$OUTPUT_PATH_networks/Network_${state_trt}_paths.ser
  network_ref=$OUTPUT_PATH_networks/Network_${state_ref}_paths.ser

 
  #control
  netpath1=$network_ref
  #condition
  netpath2=$network_trt
  ann1=$state_ref
  ann2=$state_trt
  foldername=$ann2
  ratioThreshold=1
  corThreshold=0.2
  top=10
  geneList=none
  
  while [[ ! -f $netpath1 ]] || [[ ! -f $netpath2 ]]
  do
    sleep 5
  done
  $JAVA -cp $LIB "netdecoder.NetDecoder" -SYMBOL $SYMBOL -GO $GO -out $OUT_DIR -E -control $ann1 -condition $ann2 -ncp $netpath1 -ndp $netpath2 -corThreshold $corThreshold -ratioThreshold $ratioThreshold -top $top -g $geneList -overlap -f $foldername

  #appending & and use wait doesn't seem to work. netdecoder may leave R process running then exiting itself.
  #  just check for file existence instead.
  #$JAVA -cp $LIB "netdecoder.NetDecoder" -SYMBOL $SYMBOL -GO $GO -out $OUT_DIR -E -control $ann1 -condition $ann2 -ncp $netpath1 -ndp $netpath2 -corThreshold $corThreshold -ratioThreshold $ratioThreshold -top $top -g $geneList -overlap -f $foldername & 
  #wait 

fi
if [[ $STAGE == "collect" ]] || [[ $STAGE == "all" ]] 
then
  lastfile=$OUTPUT_PATH_analysis/${state_trt}_IMPACT_SCORE_combinedScript_${state_trt}.Rout
  #while file is opened or not created, wait
  while [[ `lsof -- $lastfile` ]] || [[ ! -f $lastfile ]]
  do
    sleep 5
  done
  #this file is the last modified.
  #use lsof
  #[m143944@franklin03 netdecoder]$ if [[ `lsof -- /bin/bash` ]]; then echo 1; else echo 2; fi                                         # 1
  #[m143944@franklin03 netdecoder]$ if [[ `lsof -- /bin/basha` ]]; then echo 1; else echo 2; fi 
  # 2
  #######################
  # the folder name is $state_trt
  ls $OUTPUT_PATH_analysis/$state_trt/ > temp_ls.out
  cd $OUTPUT_PATH_analysis

  mkdir -p ../collect

  #targets
  cp $OUTPUT_PATH_analysis/$state_trt/*targets.pdf ../collect
  cp $OUTPUT_PATH_analysis/$state_trt/*SINKS.txt ../collect
  
  #key genes
  cp $OUTPUT_PATH_analysis/${state_trt}_IMPACT_SCORE_*.txt ../collect/
  cp $OUTPUT_PATH_analysis/${state_trt}_IMPACT_SCORE_*.pdf ../collect/
  
  #routers
  cp $OUTPUT_PATH_analysis/$state_trt/*_HIDDEN.txt ../collect/
  cp $OUTPUT_PATH_analysis/$state_trt/*routers.pdf ../collect/
  
  #key edges
  cp $OUTPUT_PATH_analysis/$state_trt/*_keyEdges.pdf ../collect/
  cp $OUTPUT_PATH_analysis/$state_trt/*_keyEdges.txt ../collect/
  
  #prioritized subnetwork
  cp $OUTPUT_PATH_analysis/$state_trt/*_PRIORITIZED_NETWORK.gml ../collect/
  cp $OUTPUT_PATH_analysis/$state_trt/*_PRIORITIZED_NETWORK.txt ../collect/

  cd ../collect
  python $S1_EXTRACT_GENES 1 *SINKS.txt *HIDDEN.txt *Edges.txt *IMPACT_SCORE_${state_trt}.txt
  python $S1_EXTRACT_GENES 2 ${state_trt}_PRIORITIZED_NETWORK.txt

  Rscript $S2_PLOT_GRAPH ${state_trt}_PRIORITIZED_NETWORK.gml
python $S3_COLLAGE *IMPACT_SCORE*.pdf *routers.pdf *targets.pdf *keyEdges.pdf
mv collaged_netdecoder.pdf collaged_${mybasename}.pdf

  cd $mypath
  rm -f $wd_basename.zip
  zip -qr $wd_basename.zip ./$wd_basename/
fi
cd $curdir


