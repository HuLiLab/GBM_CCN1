#!/bin/env python


import os
import sys


if len(sys.argv)<3:#
  print 'usage: '+os.path.basename(__file__)+' <first_n_columns: positive integer> <file1.txt> <file2.txt> <...>'
  sys.exit()
#end if

ncol=int(sys.argv[1])
if ncol<=0:
  print 'ncol is not a positive integer. exit. ncol=%s'%ncol
  sys.exit()
fl=sys.argv[2:]

for fn in fl:
  fntrunc=os.path.join(  os.path.dirname(os.path.abspath(fn)), os.path.splitext(os.path.basename(fn))[0] )
  s_genes=set()
  print 'processing file %s'%fn
  iline=0
  for l in open(fn, 'rb'):
    sl=l.strip()
    if sl=='': continue
    iline+=1
    splt=sl.split('\t')
    if iline==1:
      print splt[0]
      if splt[0].lower() in set(['genes', 'gene', 'expression', 'from']): continue
    #end if
    for g in splt[:ncol]:
      s_t=None
      if '->' in g: 
        s_t=set([v.strip() for v in g.split('->')])
      else: s_t=set([g])
      s_genes |= s_t
    #end for g
  #end for l
  s_genes -= set(['t', 's'])#sink and source nodes
  fnout=fntrunc+'_genes.txt'
  fout=open(fnout, 'wb')
  for g in sorted(list(s_genes)): fout.write('%s\n'%g)
  fout.close()
  print '%d genes written to file %s'%(len(s_genes), fnout)
#end for fn
