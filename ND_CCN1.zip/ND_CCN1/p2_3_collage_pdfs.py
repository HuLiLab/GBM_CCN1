#!/usr/env python

import PyPDF2
import sys
import os
import time


print '''for collection of netdecoder results
	file_1:cluster1_IMPACT_SCORE_cluster1.pdf
file_2:cluster1_Network routers.pdf	file_3:cluster1_Key targets.pdf
	file_4:cluster1_keyEdges.pdf
'''
if len(sys.argv)!=5:
  print 'usage: '+os.path.basename(__file__)+' <1.pdf> <2.pdf> <3.pdf> <4.pdf>'
  print '  collage these files into the following layout:'
  sys.exit()
#
fn1=sys.argv[1]
fn2=sys.argv[2]
fn3=sys.argv[3]
fn4=sys.argv[4]


p1=PyPDF2.PdfFileReader(fn1).getPage(0)
p2=PyPDF2.PdfFileReader(fn2).getPage(0)
p3=PyPDF2.PdfFileReader(fn3).getPage(0)
p4=PyPDF2.PdfFileReader(fn4).getPage(0)


h1=p1.mediaBox.getHeight()
h2=p2.mediaBox.getHeight()
h3=p3.mediaBox.getHeight()
h4=p4.mediaBox.getHeight()

w1=p1.mediaBox.getWidth()
w2=p2.mediaBox.getWidth()
w3=p3.mediaBox.getWidth()
w4=p4.mediaBox.getWidth()


out_h=h1+max(h2, h3)+h4
out_w=max(max(w1, w2+w3), w4)

xadj_p1=(out_w-w1)/2.0
xadj_p2=(out_w-w2-w3)/2.0
xadj_p3=xadj_p2
xadj_p4=(out_w-w4)/2.0



pageout=PyPDF2.pdf.PageObject.createBlankPage(width=out_w, height=out_h)
pageout.mergeTranslatedPage(p1, tx=xadj_p1, ty=out_h-h1)
pageout.mergeTranslatedPage(p2, tx=xadj_p2, ty=h4)
pageout.mergeTranslatedPage(p3, tx=w2+xadj_p3, ty=h4)
pageout.mergeTranslatedPage(p4, tx=xadj_p4, ty=0)


pw=PyPDF2.PdfFileWriter()
pw.addPage(pageout)
pdfout='collaged_netdecoder.pdf'
print 'output to file ', pdfout
pw.write(open(pdfout, 'wb'))

